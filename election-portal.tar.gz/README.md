# ACSES Election Portal

A secure and modern web-based voting system for ACSES Elections.

## Security Features

- CSRF Protection
- SQL Injection Prevention
- XSS Protection
- Rate Limiting
- Secure Session Management
- Password Hashing
- Input Validation
- HTTPS Enforcement
- IP-based Voting Restrictions
- Audit Logging

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- SSL Certificate (for HTTPS)

## Installation

1. Clone the repository to your web server directory:
```bash
git clone https://github.com/yourusername/acses-election.git
cd acses-election
```

2. Create a MySQL database and import the schema:
```bash
mysql -u your_username -p your_database < database.sql
```

3. Configure the database connection:
   - Open `config.php`
   - Update the database credentials:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'your_username');
     define('DB_PASS', 'your_password');
     define('DB_NAME', 'your_database');
     ```

4. Set up SSL:
   - Install an SSL certificate
   - Configure your web server to use HTTPS
   - Update `SITE_URL` in `config.php` to use HTTPS

5. Set proper permissions:
```bash
chmod 755 -R .
chmod 777 -R logs/
```

6. Create required directories:
```bash
mkdir logs
mkdir uploads
chmod 777 uploads
```

## Usage

1. Access the portal through your web browser:
```
https://your-domain.com/
```

2. Log in with your credentials

3. View active elections and cast your vote

## Security Best Practices

1. Regularly update PHP and MySQL to their latest versions
2. Keep all dependencies up to date
3. Monitor the audit logs for suspicious activities
4. Regularly backup the database
5. Use strong passwords for all accounts
6. Enable two-factor authentication for admin accounts

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, please contact the system administrator at admin@acses.edu 